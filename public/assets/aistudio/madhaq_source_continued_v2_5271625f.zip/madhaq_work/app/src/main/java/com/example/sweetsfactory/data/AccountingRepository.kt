package com.example.sweetsfactory.data

import androidx.room.withTransaction
import java.util.UUID

class AccountingRepository(internal val db: AppDatabase) {
    private fun id() = UUID.randomUUID().toString()

    // Percentage commission is stored in basis points: 500 = 5.00%.
    private fun commission(type: String, value: Long, quantity: Long, unitPrice: Long): Long {
        return when (type) {
            "PER_PIECE" -> Math.multiplyExact(value, quantity)
            "PERCENT" -> Math.multiplyExact(Math.multiplyExact(quantity, unitPrice), value) / 10_000L
            else -> 0L
        }
    }

    suspend fun addDistributor(name: String, phone: String, limit: Long, type: String, commissionValue: Long) {
        require(name.isNotBlank()) { "اسم الموزع مطلوب" }
        require(limit >= 0 && commissionValue >= 0) { "القيم لا يمكن أن تكون سالبة" }
        require(type in setOf("PER_PIECE", "PERCENT")) { "نوع العمولة غير صحيح" }
        db.distributorDao().insert(
            Distributor(id(), name.trim(), phone.trim(), limit, type, commissionValue)
        )
    }

    suspend fun addProduct(name: String, factoryPrice: Long, distributorPrice: Long, stock: Long) {
        require(name.isNotBlank()) { "اسم المنتج مطلوب" }
        require(factoryPrice >= 0 && distributorPrice >= 0 && stock >= 0)
        db.productDao().insert(
            Product(id(), name.trim(), factoryPriceYER = factoryPrice,
                distributorPriceYER = distributorPrice, stockQty = stock)
        )
    }

    suspend fun recordDistribution(
        distributorId: String,
        productId: String,
        quantity: Long,
        cashPaidYER: Long,
        note: String = ""
    ) {
        require(quantity > 0) { "الكمية يجب أن تكون أكبر من صفر" }
        require(cashPaidYER >= 0) { "النقدي لا يمكن أن يكون سالبًا" }
        db.withTransaction {
            val distributor = db.distributorDao().getById(distributorId)
                ?: error("الموزع غير موجود")
            val product = db.productDao().getById(productId)
                ?: error("المنتج غير موجود")
            val changed = db.productDao().changeStock(productId, -quantity)
            check(changed == 1) { "المخزون غير كافٍ" }

            val total = Math.multiplyExact(quantity, product.distributorPriceYER)
            require(cashPaidYER <= total) { "النقدي أكبر من قيمة التوزيع" }
            val credit = total - cashPaidYER
            val distId = id()
            val now = System.currentTimeMillis()
            val commissionYER = commission(distributor.commissionType, distributor.commissionValue,
                quantity, product.distributorPriceYER)
            val currentDebt = Math.addExact(distributor.openingDebtYER, db.distributorDao().ledgerBalance(distributorId))
            val projectedDebt = Math.addExact(currentDebt, credit)
            require(distributor.debtLimitYER == 0L || projectedDebt <= distributor.debtLimitYER) {
                "العملية تتجاوز سقف الدين المحدد"
            }

            db.distributionDao().insert(
                Distribution(distId, "DST-${now}", distributorId, now, total, cashPaidYER, credit, note = note)
            )
            db.distributionDao().insertItems(listOf(
                DistributionItem(id(), distId, productId, quantity, product.distributorPriceYER,
                    distributor.commissionType, distributor.commissionValue, commissionYER)
            ))
            db.stockMovementDao().insert(StockMovement(id(), productId, now, -quantity, "DISTRIBUTION", distId))
            if (credit > 0) db.accountDao().insert(
                AccountEntry(id(), distributorId, now, "DISTRIBUTION_CREDIT", credit, distId, "دين توزيع")
            )
            // Commission is recorded as a separate credit balance owed to distributor.
            if (commissionYER > 0) db.accountDao().insert(
                AccountEntry(id(), distributorId, now, "COMMISSION_EARNED", commissionYER, distId, "عمولة مكتسبة")
            )
        }
    }

    suspend fun recordCollection(distributorId: String, amountYER: Long, note: String = "") {
        require(amountYER > 0) { "قيمة التحصيل يجب أن تكون أكبر من صفر" }
        db.withTransaction {
            val distributor = db.distributorDao().getById(distributorId) ?: error("الموزع غير موجود")
            val outstandingDebt = Math.addExact(distributor.openingDebtYER, db.distributorDao().ledgerBalance(distributorId))
            require(amountYER <= outstandingDebt) { "التحصيل أكبر من الدين المسجل؛ سجل الزيادة كتسوية منفصلة بعد إضافة هذه الميزة" }
            val now = System.currentTimeMillis()
            val entryId = id()
            db.collectionDao().insert(CollectionEntry(entryId, distributorId, now, amountYER, note = note))
            db.accountDao().insert(AccountEntry(id(), distributorId, now, "COLLECTION", amountYER, entryId, note))
        }
    }
}


// المرحلة الثانية: الموردون والمشتريات والمواد الخام والإنتاج.
suspend fun AccountingRepository.addSupplier(name: String, phone: String, address: String = "", openingBalanceYER: Long = 0) {
    require(name.isNotBlank()) { "اسم المورد مطلوب" }
    require(openingBalanceYER >= 0) { "الرصيد الافتتاحي لا يمكن أن يكون سالبًا" }
    db.withTransaction {
        val supplierId = UUID.randomUUID().toString()
        db.supplierDao().insert(Supplier(supplierId, name.trim(), phone.trim(), address.trim(), openingBalanceYER))
        if (openingBalanceYER > 0) {
            db.supplierEntryDao().insert(SupplierEntry(
                UUID.randomUUID().toString(), supplierId, System.currentTimeMillis(),
                "OPENING_BALANCE", openingBalanceYER, null, "رصيد افتتاحي للمورد"
            ))
        }
    }
}

suspend fun AccountingRepository.addRawMaterial(name: String, unit: String, initialQtyMilli: Long, minimumQtyMilli: Long, unitCostYER: Long) {
    require(name.isNotBlank()) { "اسم المادة مطلوب" }
    require(initialQtyMilli >= 0 && minimumQtyMilli >= 0 && unitCostYER >= 0) { "القيم لا يمكن أن تكون سالبة" }
    db.withTransaction {
        val materialId = UUID.randomUUID().toString()
        db.rawMaterialDao().insert(RawMaterial(materialId, name.trim(), unit.ifBlank { "كيلو" }, initialQtyMilli, minimumQtyMilli, unitCostYER))
        if (initialQtyMilli > 0) {
            db.stockMovementDao().insert(StockMovement(UUID.randomUUID().toString(), materialId, System.currentTimeMillis(), initialQtyMilli, "RAW_OPENING", null, "رصيد افتتاحي للمادة الخام"))
        }
    }
}

suspend fun AccountingRepository.recordPurchase(
    supplierId: String,
    rawMaterialId: String,
    quantityMilli: Long,
    unitCostYER: Long,
    cashPaidYER: Long,
    note: String = ""
) {
    require(quantityMilli > 0 && unitCostYER >= 0 && cashPaidYER >= 0) { "تحقق من الكمية والسعر والمبلغ النقدي" }
    db.withTransaction {
        val supplier = db.supplierDao().getById(supplierId) ?: error("المورد غير موجود")
        val material = db.rawMaterialDao().getById(rawMaterialId) ?: error("المادة الخام غير موجودة")
        val lineTotal = Math.multiplyExact(quantityMilli, unitCostYER) / 1000L
        require(cashPaidYER <= lineTotal) { "المبلغ النقدي أكبر من إجمالي الفاتورة" }
        val purchaseId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val credit = lineTotal - cashPaidYER
        db.purchaseDao().insert(Purchase(purchaseId, "PUR-$now", supplierId, now, lineTotal, cashPaidYER, credit, note))
        db.purchaseDao().insertItems(listOf(PurchaseItem(UUID.randomUUID().toString(), purchaseId, rawMaterialId, quantityMilli, unitCostYER, lineTotal)))
        val stockChanged = db.rawMaterialDao().changeStock(rawMaterialId, quantityMilli)
        check(stockChanged == 1) { "تعذر تحديث مخزون المادة الخام" }
        db.stockMovementDao().insert(StockMovement(UUID.randomUUID().toString(), rawMaterialId, now, quantityMilli, "PURCHASE", purchaseId, note))
        if (credit > 0) db.supplierEntryDao().insert(SupplierEntry(UUID.randomUUID().toString(), supplierId, now, "PURCHASE_CREDIT", credit, purchaseId, "رصيد مشتريات آجل"))
        // Weighted average cost uses thousandth-quantity units.
        val oldQty = material.stockQtyMilli
        val newQty = Math.addExact(oldQty, quantityMilli)
        val weightedCost = if (newQty == 0L) unitCostYER else
            ((oldQty.toBigInteger() * material.averageCostPerUnitYER.toBigInteger() +
              quantityMilli.toBigInteger() * unitCostYER.toBigInteger()) / newQty.toBigInteger()).toLong()
        db.rawMaterialDao().updateAverageCost(rawMaterialId, weightedCost)
    }
}

suspend fun AccountingRepository.recordSupplierPayment(supplierId: String, amountYER: Long, note: String = "") {
    require(amountYER > 0) { "مبلغ السداد يجب أن يكون أكبر من صفر" }
    db.withTransaction {
        db.supplierDao().getById(supplierId) ?: error("المورد غير موجود")
        val outstanding = db.supplierDao().ledgerBalance(supplierId)
        require(amountYER <= outstanding) { "السداد أكبر من رصيد المورد المستحق" }
        val now = System.currentTimeMillis()
        db.supplierEntryDao().insert(SupplierEntry(UUID.randomUUID().toString(), supplierId, now, "PAYMENT", amountYER, null, note))
    }
}


/**
 * يسجل دفعة إنتاج من وصفة موجودة.
 * الكميات في recipe_items بوحدة الألف من وحدة المادة، وoutputQty هو عدد الوحدات المنتجة في الدفعة.
 * كل الخصومات والإضافة إلى المخزون تتم داخل معاملة واحدة.
 */
suspend fun AccountingRepository.recordProductionBatch(
    recipeId: String,
    plannedQty: Long,
    producedQty: Long,
    damagedQty: Long,
    note: String = ""
) {
    require(plannedQty > 0) { "الكمية المخططة يجب أن تكون أكبر من صفر" }
    require(producedQty >= 0 && damagedQty >= 0) { "الكميات لا يمكن أن تكون سالبة" }
    require(Math.addExact(producedQty, damagedQty) <= plannedQty) { "الإنتاج والتالف لا يمكن أن يتجاوزا الكمية المخططة" }

    db.withTransaction {
        val recipe = db.recipeDao().getRecipe(recipeId) ?: error("الوصفة غير موجودة")
        val product = db.productDao().getById(recipe.productId) ?: error("المنتج المرتبط بالوصفة غير موجود")
        val recipeItems = db.recipeDao().itemsForRecipe(recipeId)
        require(recipeItems.isNotEmpty()) { "لا يمكن الإنتاج بوصفة بلا مواد" }

        // نحسب الاستهلاك بالتناسب مع حجم الدفعة، مع التقريب للأعلى لتجنب نقص المواد المسحوبة.
        var materialCost = 0L
        for (item in recipeItems) {
            val material = db.rawMaterialDao().getById(item.rawMaterialId)
                ?: error("إحدى مواد الوصفة غير موجودة")
            // ingredient quantity is defined for recipe.outputQty finished units
            val numerator = Math.multiplyExact(item.quantityMilli, plannedQty)
            val needed = Math.addExact(numerator, recipe.outputQty - 1L) / recipe.outputQty
            require(material.stockQtyMilli >= needed) {
                "المخزون غير كافٍ من المادة: ${material.name}"
            }
            val changed = db.rawMaterialDao().changeStock(material.id, -needed)
            require(changed == 1) { "تعذر خصم المادة: ${material.name}" }
            val cost = Math.multiplyExact(needed, material.averageCostPerUnitYER) / 1000L
            materialCost = Math.addExact(materialCost, cost)
            db.stockMovementDao().insert(
                StockMovement(
                    UUID.randomUUID().toString(), material.id, System.currentTimeMillis(),
                    -needed, "PRODUCTION_CONSUMPTION", recipeId, "استهلاك لدفعة إنتاج"
                )
            )
        }

        val now = System.currentTimeMillis()
        val batchId = UUID.randomUUID().toString()
        db.productionDao().insert(
            ProductionBatch(
                batchId, "PRD-$now", product.id, now, plannedQty,
                producedQty, damagedQty, materialCost, note
            )
        )
        if (producedQty > 0) {
            val changed = db.productDao().changeStock(product.id, producedQty)
            require(changed == 1) { "تعذر تحديث مخزون المنتج النهائي" }
            db.stockMovementDao().insert(
                StockMovement(
                    UUID.randomUUID().toString(), product.id, now,
                    producedQty, "PRODUCTION_OUTPUT", batchId, "إنتاج صالح"
                )
            )
        }
        if (damagedQty > 0) {
            db.stockMovementDao().insert(
                StockMovement(
                    UUID.randomUUID().toString(), product.id, now,
                    0L, "PRODUCTION_DAMAGE", batchId, "تالف أثناء الإنتاج: $damagedQty"
                )
            )
        }
    }
}


suspend fun AccountingRepository.addRecipe(
    productId: String,
    name: String,
    outputQty: Long,
    ingredients: List<Pair<String, Long>>
) {
    require(name.isNotBlank()) { "اسم الوصفة مطلوب" }
    require(outputQty > 0) { "حجم دفعة الوصفة يجب أن يكون أكبر من صفر" }
    require(ingredients.isNotEmpty()) { "أضف مادة واحدة على الأقل للوصفة" }
    require(ingredients.all { it.second > 0 }) { "كمية كل مادة يجب أن تكون أكبر من صفر" }
    require(ingredients.map { it.first }.distinct().size == ingredients.size) { "لا تكرر المادة نفسها في الوصفة؛ اجمع كميتها في بند واحد" }
    db.withTransaction {
        db.productDao().getById(productId) ?: error("المنتج غير موجود")
        ingredients.forEach { (materialId, _) ->
            db.rawMaterialDao().getById(materialId) ?: error("مادة خام غير موجودة")
        }
        val recipeId = UUID.randomUUID().toString()
        db.recipeDao().insert(Recipe(recipeId, productId, name.trim(), outputQty))
        db.recipeDao().insertItems(
            ingredients.map { (materialId, qty) ->
                RecipeItem(UUID.randomUUID().toString(), recipeId, materialId, qty)
            }
        )
    }
}
