package com.example.sweetsfactory.data

import android.content.Context
import androidx.room.Entity
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Entity(tableName = "settings")
data class SettingRow(@androidx.room.PrimaryKey val key: String, val value: String)

@Database(
    entities = [
        Distributor::class, Product::class, Distribution::class, DistributionItem::class,
        CollectionEntry::class, ReturnEntry::class, DamageEntry::class, AccountEntry::class,
        StockMovement::class, SettingRow::class,
        Supplier::class, RawMaterial::class, Purchase::class, PurchaseItem::class,
        Recipe::class, RecipeItem::class, ProductionBatch::class, SupplierEntry::class
    ],
    version = 2,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun distributorDao(): DistributorDao
    abstract fun productDao(): ProductDao
    abstract fun distributionDao(): DistributionDao
    abstract fun collectionDao(): CollectionDao
    abstract fun returnDao(): ReturnDao
    abstract fun damageDao(): DamageDao
    abstract fun accountDao(): AccountDao
    abstract fun stockMovementDao(): StockMovementDao
    abstract fun settingsDao(): SettingsDao
    abstract fun supplierDao(): SupplierDao
    abstract fun rawMaterialDao(): RawMaterialDao
    abstract fun purchaseDao(): PurchaseDao
    abstract fun supplierEntryDao(): SupplierEntryDao
    abstract fun recipeDao(): RecipeDao
    abstract fun productionDao(): ProductionDao

    companion object {
        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS suppliers (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL, openingBalanceYER INTEGER NOT NULL, active INTEGER NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_suppliers_name ON suppliers(name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS raw_materials (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, unit TEXT NOT NULL, stockQtyMilli INTEGER NOT NULL, minimumQtyMilli INTEGER NOT NULL, averageCostPerUnitYER INTEGER NOT NULL, active INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_raw_materials_name ON raw_materials(name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS purchases (id TEXT NOT NULL PRIMARY KEY, displayNumber TEXT NOT NULL, supplierId TEXT NOT NULL, createdAt INTEGER NOT NULL, totalYER INTEGER NOT NULL, cashPaidYER INTEGER NOT NULL, creditYER INTEGER NOT NULL, note TEXT NOT NULL, FOREIGN KEY(supplierId) REFERENCES suppliers(id) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_purchases_supplierId ON purchases(supplierId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_purchases_createdAt ON purchases(createdAt)")
                db.execSQL("CREATE TABLE IF NOT EXISTS purchase_items (id TEXT NOT NULL PRIMARY KEY, purchaseId TEXT NOT NULL, rawMaterialId TEXT NOT NULL, quantityMilli INTEGER NOT NULL, unitCostYER INTEGER NOT NULL, lineTotalYER INTEGER NOT NULL, FOREIGN KEY(purchaseId) REFERENCES purchases(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(rawMaterialId) REFERENCES raw_materials(id) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_items_purchaseId ON purchase_items(purchaseId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_items_rawMaterialId ON purchase_items(rawMaterialId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS recipes (id TEXT NOT NULL PRIMARY KEY, productId TEXT NOT NULL, name TEXT NOT NULL, outputQty INTEGER NOT NULL, active INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recipes_productId ON recipes(productId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS recipe_items (id TEXT NOT NULL PRIMARY KEY, recipeId TEXT NOT NULL, rawMaterialId TEXT NOT NULL, quantityMilli INTEGER NOT NULL, FOREIGN KEY(recipeId) REFERENCES recipes(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(rawMaterialId) REFERENCES raw_materials(id) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recipe_items_recipeId ON recipe_items(recipeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recipe_items_rawMaterialId ON recipe_items(rawMaterialId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS production_batches (id TEXT NOT NULL PRIMARY KEY, displayNumber TEXT NOT NULL, productId TEXT NOT NULL, createdAt INTEGER NOT NULL, plannedQty INTEGER NOT NULL, producedQty INTEGER NOT NULL, damagedQty INTEGER NOT NULL, materialCostYER INTEGER NOT NULL, note TEXT NOT NULL, FOREIGN KEY(productId) REFERENCES products(id) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_production_batches_productId ON production_batches(productId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_production_batches_createdAt ON production_batches(createdAt)")
                db.execSQL("CREATE TABLE IF NOT EXISTS supplier_entries (id TEXT NOT NULL PRIMARY KEY, supplierId TEXT NOT NULL, createdAt INTEGER NOT NULL, kind TEXT NOT NULL, amountYER INTEGER NOT NULL, sourceId TEXT, note TEXT NOT NULL, FOREIGN KEY(supplierId) REFERENCES suppliers(id) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_supplier_entries_supplierId ON supplier_entries(supplierId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_supplier_entries_createdAt ON supplier_entries(createdAt)")
            }
        }
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sweets_factory.db"
                ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
            }
    }
}
