package com.example.sweetsfactory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.sweetsfactory.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import java.time.format.DateTimeFormatter

private val yerFormat = NumberFormat.getIntegerInstance(Locale("ar", "YE"))
private fun yer(value: Long) = "${yerFormat.format(value)} ر.ي"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        val repo = AccountingRepository(db)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = androidx.compose.ui.graphics.Color(0xFFE8AD3D),
                    onPrimary = androidx.compose.ui.graphics.Color(0xFF20150B),
                    secondary = androidx.compose.ui.graphics.Color(0xFF8B4513),
                    background = androidx.compose.ui.graphics.Color(0xFFF7F3EC),
                    surface = androidx.compose.ui.graphics.Color(0xFFFFFFFF)
                )
            ) {
                MainScreen(db, repo)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen(db: AppDatabase, repo: AccountingRepository) {
    val distributors by db.distributorDao().observeAll().collectAsState(initial = emptyList())
    val products by db.productDao().observeAll().collectAsState(initial = emptyList())
    val allEntries by db.distributorDao().observeAllEntries().collectAsState(initial = emptyList())
    val suppliers by db.supplierDao().observeAll().collectAsState(initial = emptyList())
    val rawMaterials by db.rawMaterialDao().observeAll().collectAsState(initial = emptyList())
    val purchases by db.purchaseDao().observeAll().collectAsState(initial = emptyList())
    val recipes by db.recipeDao().observeAll().collectAsState(initial = emptyList())
    val productionBatches by db.productionDao().observeAll().collectAsState(initial = emptyList())
    val supplierEntries by db.supplierEntryDao().observeAllEntries().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf("") }
    var showAddDistributor by remember { mutableStateOf(false) }
    var showAddProduct by remember { mutableStateOf(false) }
    var showDistribution by remember { mutableStateOf(false) }
    var showCollection by remember { mutableStateOf(false) }
    var selectedDistributor by remember { mutableStateOf("") }
    var showAddSupplier by remember { mutableStateOf(false) }
    var showAddRawMaterial by remember { mutableStateOf(false) }
    var showPurchase by remember { mutableStateOf(false) }
    var showRecipe by remember { mutableStateOf(false) }
    var showProduction by remember { mutableStateOf(false) }
    var showSupplierPayment by remember { mutableStateOf(false) }
    var selectedSupplier by remember { mutableStateOf("") }

    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf("الرئيسية", "الموزعون", "المنتجات", "الحركات", "الخميس", "المخزون").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, label = { Text(label) },
                        icon = { Text(listOf("⌂", "♙", "▦", "↔", "ر.ي", "م")[i]) })
                }
            }
        },
        topBar = {
            TopAppBar(
                title = { Text("مذاق | MADHAQ", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painter = painterResource(id = com.example.sweetsfactory.R.drawable.madhaq_logo), contentDescription = "شعار معمل مذاق", modifier = Modifier.fillMaxWidth().height(150.dp), contentScale = ContentScale.Fit)
                    Text("نظام إدارة المعمل والتوزيع", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
            }
            if (message.isNotBlank()) {
                AssistChip(onClick = { message = "" }, label = { Text(message) })
            }
            when (tab) {
                0 -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryCard("الموزعون", distributors.size.toString(), Modifier.weight(1f))
                        SummaryCard("المنتجات", products.size.toString(), Modifier.weight(1f))
                    }
                    Text("عمليات سريعة", style = MaterialTheme.typography.titleMedium)
                    Button(onClick = { showDistribution = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ توزيع جديد") }
                    OutlinedButton(onClick = { showCollection = true }, modifier = Modifier.fillMaxWidth()) { Text("💰 تسجيل تحصيل") }
                    OutlinedButton(onClick = { showAddDistributor = true }, modifier = Modifier.fillMaxWidth()) { Text("إضافة موزع") }
                    OutlinedButton(onClick = { showAddProduct = true }, modifier = Modifier.fillMaxWidth()) { Text("إضافة منتج") }
                    Text("البيانات محفوظة محليًا على هذا الجهاز وتعمل دون إنترنت.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                1 -> {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("الموزعون", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                        Button(onClick = { showAddDistributor = true }) { Text("إضافة") }
                    }
                    if (distributors.isEmpty()) Text("لا يوجد موزعون. اضغط إضافة لبدء التسجيل.")
                    distributors.forEach { d ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(d.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(d.phone.ifBlank { "لا يوجد هاتف" })
                                Text("سقف الدين: ${if (d.debtLimitYER == 0L) "غير محدد" else yer(d.debtLimitYER)}")
                                Text("العمولة: " + if (d.commissionType == "PER_PIECE") "${yer(d.commissionValue)} لكل قطعة" else "${d.commissionValue / 100.0}%")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { selectedDistributor = d.id; showCollection = true }) { Text("تحصيل") }
                                    OutlinedButton(onClick = { selectedDistributor = d.id; showDistribution = true }) { Text("توزيع") }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("المنتجات", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                        Button(onClick = { showAddProduct = true }) { Text("إضافة") }
                    }
                    if (products.isEmpty()) Text("لا توجد منتجات بعد.")
                    products.forEach { p ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("سعر الموزع: ${yer(p.distributorPriceYER)}")
                                Text("المخزون: ${p.stockQty} ${p.unit}")
                            }
                        }
                    }
                }
                3 -> {
                    Text("الحركات", style = MaterialTheme.typography.titleLarge)
                    Text("التوزيعات والتحصيلات تحفظ محليًا داخل قاعدة البيانات.")
                    Text("عدد قيود الحساب المسجلة: ${allEntries.size}")
                    allEntries.take(30).forEach { entry ->
                        val dName = distributors.firstOrNull { it.id == entry.distributorId }?.name ?: "موزع غير معروف"
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(dName, fontWeight = FontWeight.Bold)
                                Text(when (entry.kind) {
                                    "DISTRIBUTION_CREDIT" -> "دين توزيع"
                                    "COLLECTION" -> "تحصيل"
                                    "COMMISSION_EARNED" -> "عمولة مستحقة (منفصلة عن الدين)"
                                    "RETURN_CREDIT" -> "مرتجع معتمد"
                                    "MANUAL_DEBIT" -> "تسوية مدينة"
                                    "MANUAL_CREDIT" -> "تسوية دائنة"
                                    else -> entry.kind
                                })
                                Text(yer(entry.amountYER))
                                Text(java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar")).format(java.util.Date(entry.createdAt)), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                5 -> {
                    Text("إدارة المخزون والمشتريات والإنتاج", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = { showAddSupplier = true }, modifier = Modifier.weight(1f)) { Text("مورد جديد") }
                        Button(onClick = { showAddRawMaterial = true }, modifier = Modifier.weight(1f)) { Text("مادة خام") }
                    }
                    Button(onClick = { showPurchase = true }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل مشتريات") }
                    OutlinedButton(onClick = { showSupplierPayment = true }, modifier = Modifier.fillMaxWidth()) { Text("سداد مستحقات مورد") }
                    Button(onClick = { showRecipe = true }, modifier = Modifier.fillMaxWidth()) { Text("إنشاء وصفة") }
                    OutlinedButton(onClick = { showProduction = true }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل دفعة إنتاج") }
                    Text("الموردون (${suppliers.size})", style = MaterialTheme.typography.titleMedium)
                    suppliers.forEach { supplier ->
                        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                            val balance = supplierEntries.filter { it.supplierId == supplier.id }.sumOf { entry ->
                                when (entry.kind) {
                                    "OPENING_BALANCE", "PURCHASE_CREDIT", "MANUAL_DEBIT" -> entry.amountYER
                                    "PAYMENT", "MANUAL_CREDIT" -> -entry.amountYER
                                    else -> 0L
                                }
                            }
                            Text(supplier.name, fontWeight = FontWeight.Bold)
                            Text("الرصيد الافتتاحي: ${yer(supplier.openingBalanceYER)} · ${supplier.phone}")
                            Text("الرصيد المستحق حاليًا: ${yer(balance)}", fontWeight = FontWeight.SemiBold)
                            OutlinedButton(onClick = { selectedSupplier = supplier.id; showSupplierPayment = true }) { Text("تسجيل سداد لهذا المورد") }
                        } }
                    }
                    Text("المواد الخام (${rawMaterials.size})", style = MaterialTheme.typography.titleMedium)
                    rawMaterials.forEach { material ->
                        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                            Text(material.name, fontWeight = FontWeight.Bold)
                            Text("المخزون: ${material.stockQtyMilli / 1000.0} ${material.unit} · متوسط التكلفة: ${yer(material.averageCostPerUnitYER)}")
                            if (material.stockQtyMilli <= material.minimumQtyMilli) Text("تنبيه: المخزون عند الحد الأدنى أو أقل", color = MaterialTheme.colorScheme.error)
                        } }
                    }
                    Text("فواتير المشتريات: ${purchases.size} · الوصفات: ${recipes.size} · دفعات الإنتاج: ${productionBatches.size}")
                    purchases.take(10).forEach { purchase ->
                        val supplierName = suppliers.firstOrNull { it.id == purchase.supplierId }?.name ?: "مورد غير معروف"
                        Text("${purchase.displayNumber} — $supplierName — الإجمالي ${yer(purchase.totalYER)} — آجل ${yer(purchase.creditYER)}")
                    }
                    recipes.forEach { recipe ->
                        val productName = products.firstOrNull { it.id == recipe.productId }?.name ?: "منتج غير معروف"
                        Text("وصفة ${recipe.name} · $productName · حجم الدفعة ${recipe.outputQty}")
                    }
                    productionBatches.take(10).forEach { batch -> Text("${batch.displayNumber}: صالح ${batch.producedQty}، تالف ${batch.damagedQty}") }
                }
                else -> {
                    val zone = ZoneId.systemDefault()
                    val today = LocalDate.now(zone)
                    val thisThursday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.THURSDAY))
                    val nextThursday = thisThursday.plusWeeks(1)
                    val startMillis = thisThursday.atStartOfDay(zone).toInstant().toEpochMilli()
                    val endMillis = nextThursday.atStartOfDay(zone).toInstant().toEpochMilli()
                    val formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd")
                    Text("كشف الخميس", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("الفترة: ${thisThursday.format(formatter)} إلى ${nextThursday.minusDays(1).format(formatter)}")
                    Text("الكشف مبدئي ويعرض القيود المسجلة فقط؛ اعتمد الأرقام بعد مراجعة الحركات والرصيد الافتتاحي.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    distributors.forEach { d ->
                        val rows = allEntries.filter { it.distributorId == d.id && it.createdAt >= startMillis && it.createdAt < endMillis }
                        val distributionCredit = rows.filter { it.kind == "DISTRIBUTION_CREDIT" || it.kind == "MANUAL_DEBIT" || it.kind == "ADVANCE" }.sumOf { it.amountYER }
                        val collections = rows.filter { it.kind == "COLLECTION" }.sumOf { it.amountYER }
                        val returnCredits = rows.filter { it.kind == "RETURN_CREDIT" || it.kind == "MANUAL_CREDIT" }.sumOf { it.amountYER }
                        val debtRows = allEntries.filter { it.distributorId == d.id && it.kind != "COMMISSION_EARNED" }
                        val closingDebt = d.openingDebtYER + debtRows.sumOf { e -> when (e.kind) {
                            "DISTRIBUTION_CREDIT", "MANUAL_DEBIT", "ADVANCE" -> e.amountYER
                            "COLLECTION", "RETURN_CREDIT", "MANUAL_CREDIT" -> -e.amountYER
                            else -> 0L
                        } }
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(d.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("دين التوزيعات والتسويات المدينة خلال الفترة: ${yer(distributionCredit)}")
                                Text("التحصيلات: ${yer(collections)}")
                                Text("المرتجعات/التسويات الدائنة: ${yer(returnCredits)}")
                                Divider()
                                Text("رصيد الدين الحالي: ${yer(closingDebt)}", fontWeight = FontWeight.Bold)
                                val commission = allEntries.filter { it.distributorId == d.id && it.kind == "COMMISSION_EARNED" && it.createdAt >= startMillis && it.createdAt < endMillis }.sumOf { it.amountYER }
                                Text("العمولة المكتسبة خلال الفترة (منفصلة): ${yer(commission)}")
                            }
                        }
                    }
                    if (distributors.isEmpty()) Text("أضف موزعًا لعرض كشفه.")
                }
            }
        }
    }

    if (showAddDistributor) AddDistributorDialog(
        onDismiss = { showAddDistributor = false },
        onSave = { name, phone, limit, type, value ->
            scope.launch {
                runCatching { repo.addDistributor(name, phone, limit, type, value) }
                    .onSuccess { message = "تمت إضافة الموزع"; showAddDistributor = false }
                    .onFailure { message = it.message ?: "تعذر الحفظ" }
            }
        }
    )
    if (showAddProduct) AddProductDialog(
        onDismiss = { showAddProduct = false },
        onSave = { name, factory, distributor, stock ->
            scope.launch {
                runCatching { repo.addProduct(name, factory, distributor, stock) }
                    .onSuccess { message = "تمت إضافة المنتج"; showAddProduct = false }
                    .onFailure { message = it.message ?: "تعذر الحفظ" }
            }
        }
    )
    if (showDistribution) DistributionDialog(
        distributors, products, selectedDistributor,
        onDismiss = { showDistribution = false; selectedDistributor = "" },
        onSave = { did, pid, qty, cash ->
            scope.launch {
                runCatching { repo.recordDistribution(did, pid, qty, cash) }
                    .onSuccess { message = "تم تسجيل التوزيع"; showDistribution = false; selectedDistributor = "" }
                    .onFailure { message = it.message ?: "تعذر حفظ التوزيع" }
            }
        }
    )
    if (showCollection) CollectionDialog(
        distributors, selectedDistributor,
        onDismiss = { showCollection = false; selectedDistributor = "" },
        onSave = { did, amount ->
            scope.launch {
                runCatching { repo.recordCollection(did, amount) }
                    .onSuccess { message = "تم تسجيل التحصيل"; showCollection = false; selectedDistributor = "" }
                    .onFailure { message = it.message ?: "تعذر حفظ التحصيل" }
            }
        }
    )
    if (showAddSupplier) SupplierDialog({ showAddSupplier = false }) { n, ph, ad, opening ->
        scope.launch { runCatching { repo.addSupplier(n, ph, ad, opening) }
            .onSuccess { message = "تمت إضافة المورد"; showAddSupplier = false }
            .onFailure { message = it.message ?: "تعذر حفظ المورد" } }
    }
    if (showAddRawMaterial) RawMaterialDialog({ showAddRawMaterial = false }) { n, unit, initial, minimum, cost ->
        scope.launch { runCatching { repo.addRawMaterial(n, unit, initial, minimum, cost) }
            .onSuccess { message = "تمت إضافة المادة الخام"; showAddRawMaterial = false }
            .onFailure { message = it.message ?: "تعذر حفظ المادة" } }
    }
    if (showPurchase) PurchaseDialog(suppliers, rawMaterials, { showPurchase = false }) { sid, mid, qty, cost, cash, note ->
        scope.launch { runCatching { repo.recordPurchase(sid, mid, qty, cost, cash, note) }
            .onSuccess { message = "تم تسجيل فاتورة الشراء"; showPurchase = false }
            .onFailure { message = it.message ?: "تعذر تسجيل الشراء" } }
    }
    if (showSupplierPayment) SupplierPaymentDialog(suppliers, supplierEntries, selectedSupplier,
        onDismiss = { showSupplierPayment = false; selectedSupplier = "" },
        onSave = { sid, amount, note ->
            scope.launch { runCatching { repo.recordSupplierPayment(sid, amount, note) }
                .onSuccess { message = "تم تسجيل سداد المورد"; showSupplierPayment = false; selectedSupplier = "" }
                .onFailure { message = it.message ?: "تعذر تسجيل السداد" } }
        })
    if (showRecipe) RecipeDialog(products, rawMaterials, { showRecipe = false }) { pid, name, output, ingredients ->
        scope.launch { runCatching { repo.addRecipe(pid, name, output, ingredients) }
            .onSuccess { message = "تم حفظ الوصفة"; showRecipe = false }
            .onFailure { message = it.message ?: "تعذر حفظ الوصفة" } }
    }
    if (showProduction) ProductionDialog(recipes, { showProduction = false }) { rid, planned, produced, damaged, note ->
        scope.launch { runCatching { repo.recordProductionBatch(rid, planned, produced, damaged, note) }
            .onSuccess { message = "تم تسجيل دفعة الإنتاج"; showProduction = false }
            .onFailure { message = it.message ?: "تعذر تسجيل الإنتاج" } }
    }
}

@Composable
private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AddDistributorDialog(onDismiss: () -> Unit, onSave: (String, String, Long, String, Long) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var limit by remember { mutableStateOf("0") }
    var type by remember { mutableStateOf("PER_PIECE") }
    var commission by remember { mutableStateOf("0") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة موزع") },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم الموزع") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("رقم الهاتف") }, singleLine = true)
                OutlinedTextField(limit, { limit = it }, label = { Text("سقف الدين بالريال (0 = دون سقف)") }, singleLine = true)
                Text("طريقة العمولة")
                Row {
                    FilterChip(selected = type == "PER_PIECE", onClick = { type = "PER_PIECE" }, label = { Text("لكل قطعة") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = type == "PERCENT", onClick = { type = "PERCENT" }, label = { Text("نسبة %") })
                }
                OutlinedTextField(commission, { commission = it }, label = { Text(if (type == "PER_PIECE") "عمولة القطعة بالريال" else "النسبة (مثال 5)") }, singleLine = true)
                Text("تنبيه: النسبة تُخزن داخليًا بنظام basis points.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = {
            val raw = commission.toDoubleOrNull() ?: 0.0
            val stored = if (type == "PERCENT") (raw * 100).toLong() else (raw.toLong())
            onSave(name, phone, limit.toLongOrNull() ?: 0, type, stored)
        }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun AddProductDialog(onDismiss: () -> Unit, onSave: (String, Long, Long, Long) -> Unit) {
    var name by remember { mutableStateOf("") }
    var factory by remember { mutableStateOf("0") }
    var distributor by remember { mutableStateOf("0") }
    var stock by remember { mutableStateOf("0") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة منتج") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم المنتج") }, singleLine = true)
                OutlinedTextField(factory, { factory = it }, label = { Text("سعر المعمل") }, singleLine = true)
                OutlinedTextField(distributor, { distributor = it }, label = { Text("سعر الموزع") }, singleLine = true)
                OutlinedTextField(stock, { stock = it }, label = { Text("الكمية الافتتاحية") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(name, factory.toLongOrNull() ?: 0, distributor.toLongOrNull() ?: 0, stock.toLongOrNull() ?: 0) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun DistributionDialog(
    distributors: List<Distributor>, products: List<Product>, presetDistributor: String,
    onDismiss: () -> Unit, onSave: (String, String, Long, Long) -> Unit
) {
    var did by remember { mutableStateOf(presetDistributor) }
    var pid by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var cash by remember { mutableStateOf("0") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("توزيع جديد") },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("اختر الموزع")
                distributors.forEach { d -> FilterChip(selected = did == d.id, onClick = { did = d.id }, label = { Text(d.name) }) }
                Text("اختر المنتج")
                products.forEach { p -> FilterChip(selected = pid == p.id, onClick = { pid = p.id }, label = { Text("${p.name} — ${p.stockQty} قطعة") }) }
                OutlinedTextField(qty, { qty = it }, label = { Text("الكمية") }, singleLine = true)
                OutlinedTextField(cash, { cash = it }, label = { Text("النقدي المستلم بالريال") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { if (did.isNotBlank() && pid.isNotBlank()) onSave(did, pid, qty.toLongOrNull() ?: 0, cash.toLongOrNull() ?: 0) }) { Text("تسجيل") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun CollectionDialog(
    distributors: List<Distributor>, presetDistributor: String,
    onDismiss: () -> Unit, onSave: (String, Long) -> Unit
) {
    var did by remember { mutableStateOf(presetDistributor) }
    var amount by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("تسجيل تحصيل") },
        text = {
            Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                distributors.forEach { d -> FilterChip(selected = did == d.id, onClick = { did = d.id }, label = { Text(d.name) }) }
                OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ بالريال اليمني") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { if (did.isNotBlank()) onSave(did, amount.toLongOrNull() ?: 0) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}


@Composable
private fun SupplierDialog(onDismiss: () -> Unit, onSave: (String, String, String, Long) -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }; var opening by remember { mutableStateOf("0") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة مورد") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("اسم المورد") }, singleLine = true)
            OutlinedTextField(phone, { phone = it }, label = { Text("الهاتف") }, singleLine = true)
            OutlinedTextField(address, { address = it }, label = { Text("العنوان") }, singleLine = true)
            OutlinedTextField(opening, { opening = it }, label = { Text("الرصيد الافتتاحي المستحق") }, singleLine = true)
        } }, confirmButton = { TextButton(onClick = { onSave(name, phone, address, opening.toLongOrNull() ?: -1) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun RawMaterialDialog(onDismiss: () -> Unit, onSave: (String, String, Long, Long, Long) -> Unit) {
    var name by remember { mutableStateOf("") }; var unit by remember { mutableStateOf("كيلو") }
    var initial by remember { mutableStateOf("0") }; var minimum by remember { mutableStateOf("0") }; var cost by remember { mutableStateOf("0") }
    fun milli(v: String): Long = ((v.toDoubleOrNull() ?: -1.0) * 1000).toLong()
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة مادة خام") },
        text = { Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("اسم المادة") }, singleLine = true)
            OutlinedTextField(unit, { unit = it }, label = { Text("الوحدة") }, singleLine = true)
            OutlinedTextField(initial, { initial = it }, label = { Text("المخزون الافتتاحي (مثال 1.250)") }, singleLine = true)
            OutlinedTextField(minimum, { minimum = it }, label = { Text("الحد الأدنى") }, singleLine = true)
            OutlinedTextField(cost, { cost = it }, label = { Text("تكلفة الوحدة بالريال") }, singleLine = true)
        } }, confirmButton = { TextButton(onClick = { onSave(name, unit, milli(initial), milli(minimum), cost.toLongOrNull() ?: -1) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun PurchaseDialog(suppliers: List<Supplier>, materials: List<RawMaterial>, onDismiss: () -> Unit,
    onSave: (String, String, Long, Long, Long, String) -> Unit) {
    var sid by remember { mutableStateOf("") }; var mid by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1.000") }; var cost by remember { mutableStateOf("0") }
    var cash by remember { mutableStateOf("0") }; var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("فاتورة شراء") },
        text = { Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("اختر المورد"); suppliers.forEach { FilterChip(sid == it.id, { sid = it.id }, label = { Text(it.name) }) }
            Text("اختر المادة"); materials.forEach { FilterChip(mid == it.id, { mid = it.id }, label = { Text(it.name) }) }
            OutlinedTextField(qty, { qty = it }, label = { Text("الكمية (مثال 1.250)") }, singleLine = true)
            OutlinedTextField(cost, { cost = it }, label = { Text("تكلفة الوحدة") }, singleLine = true)
            OutlinedTextField(cash, { cash = it }, label = { Text("المدفوع نقدًا") }, singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("ملاحظات") }, singleLine = true)
        } }, confirmButton = { TextButton(onClick = { if (sid.isNotBlank() && mid.isNotBlank()) onSave(sid, mid, ((qty.toDoubleOrNull() ?: 0.0) * 1000).toLong(), cost.toLongOrNull() ?: 0, cash.toLongOrNull() ?: 0, note) }) { Text("تسجيل") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun RecipeDialog(products: List<Product>, materials: List<RawMaterial>, onDismiss: () -> Unit,
    onSave: (String, String, Long, List<Pair<String, Long>>) -> Unit) {
    var pid by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("100") }
    val ingredients = remember { mutableStateListOf<Pair<String, String>>() }
    LaunchedEffect(materials) {
        if (ingredients.isEmpty() && materials.isNotEmpty()) ingredients.add(materials.first().id to "1.000")
    }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إنشاء وصفة متعددة المكونات") },
        text = { Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("اسم الوصفة") }, singleLine = true)
            Text("المنتج الناتج"); products.forEach { product ->
                FilterChip(pid == product.id, { pid = product.id }, label = { Text(product.name) })
            }
            OutlinedTextField(output, { output = it }, label = { Text("عدد الوحدات الناتجة من الوصفة") }, singleLine = true)
            Divider()
            Text("المكونات", style = MaterialTheme.typography.titleSmall)
            ingredients.forEachIndexed { index, ingredient ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("المكون ${index + 1}")
                    materials.forEach { material ->
                        FilterChip(ingredient.first == material.id, {
                            ingredients[index] = material.id to ingredient.second
                        }, label = { Text(material.name) })
                    }
                    OutlinedTextField(ingredient.second, { value ->
                        ingredients[index] = ingredient.first to value
                    }, label = { Text("الكمية (مثال 1.250)") }, singleLine = true)
                    if (ingredients.size > 1) TextButton(onClick = { ingredients.removeAt(index) }) { Text("حذف هذا المكون") }
                } }
            }
            OutlinedButton(onClick = {
                if (materials.isNotEmpty()) ingredients.add(materials.first().id to "1.000")
            }, enabled = materials.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة مكون") }
            if (materials.isEmpty()) Text("أضف المواد الخام أولًا حتى تتمكن من إنشاء وصفة.", color = MaterialTheme.colorScheme.error)
        } }, confirmButton = { TextButton(onClick = {
            val parsed = ingredients.map { (materialId, quantity) -> materialId to ((quantity.toDoubleOrNull() ?: 0.0) * 1000).toLong() }
            if (pid.isNotBlank() && parsed.isNotEmpty() && parsed.all { it.first.isNotBlank() && it.second > 0 } && parsed.map { it.first }.distinct().size == parsed.size) {
                onSave(pid, name, output.toLongOrNull() ?: 0, parsed)
            }
        }, enabled = products.isNotEmpty() && materials.isNotEmpty()) { Text("حفظ الوصفة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun SupplierPaymentDialog(suppliers: List<Supplier>, entries: List<SupplierEntry>, presetSupplier: String,
    onDismiss: () -> Unit, onSave: (String, Long, String) -> Unit) {
    var sid by remember { mutableStateOf(presetSupplier) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val selected = suppliers.firstOrNull { it.id == sid }
    val balance = selected?.let { supplier -> entries.filter { it.supplierId == supplier.id }.sumOf { entry ->
        when (entry.kind) {
            "OPENING_BALANCE", "PURCHASE_CREDIT", "MANUAL_DEBIT" -> entry.amountYER
            "PAYMENT", "MANUAL_CREDIT" -> -entry.amountYER
            else -> 0L
        }
    } } ?: 0L
    AlertDialog(onDismissRequest = onDismiss, title = { Text("سداد مستحقات مورد") },
        text = { Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            suppliers.forEach { supplier -> FilterChip(sid == supplier.id, { sid = supplier.id }, label = { Text(supplier.name) }) }
            if (selected != null) Text("الرصيد المستحق: ${yer(balance)}")
            OutlinedTextField(amount, { amount = it }, label = { Text("مبلغ السداد بالريال اليمني") }, singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("ملاحظات (اختياري)") }, singleLine = true)
        } }, confirmButton = { TextButton(onClick = {
            val value = amount.toLongOrNull() ?: 0L
            if (sid.isNotBlank() && value > 0 && value <= balance) onSave(sid, value, note)
        }, enabled = selected != null && balance > 0) { Text("تسجيل السداد") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun ProductionDialog(recipes: List<Recipe>, onDismiss: () -> Unit,
    onSave: (String, Long, Long, Long, String) -> Unit) {
    var rid by remember { mutableStateOf("") }; var planned by remember { mutableStateOf("1") }
    var produced by remember { mutableStateOf("1") }; var damaged by remember { mutableStateOf("0") }; var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("تسجيل دفعة إنتاج") },
        text = { Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            recipes.forEach { FilterChip(rid == it.id, { rid = it.id }, label = { Text(it.name) }) }
            OutlinedTextField(planned, { planned = it }, label = { Text("الكمية المخططة") }, singleLine = true)
            OutlinedTextField(produced, { produced = it }, label = { Text("الكمية الصالحة") }, singleLine = true)
            OutlinedTextField(damaged, { damaged = it }, label = { Text("الكمية التالفة") }, singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("ملاحظات") }, singleLine = true)
        } }, confirmButton = { TextButton(onClick = { if (rid.isNotBlank()) onSave(rid, planned.toLongOrNull() ?: 0, produced.toLongOrNull() ?: 0, damaged.toLongOrNull() ?: 0, note) }) { Text("تسجيل") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}
