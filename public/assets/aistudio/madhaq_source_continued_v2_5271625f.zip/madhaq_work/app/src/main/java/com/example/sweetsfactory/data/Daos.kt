package com.example.sweetsfactory.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface DistributorDao {
    @Query("SELECT * FROM distributors WHERE active = 1 ORDER BY name")
    fun observeAll(): Flow<List<Distributor>>

    @Query("SELECT * FROM distributors WHERE id = :id")
    suspend fun getById(id: String): Distributor?

    @Insert
    suspend fun insert(item: Distributor)

    @Query("SELECT COALESCE(SUM(CASE WHEN kind IN ('DISTRIBUTION_CREDIT','MANUAL_DEBIT','ADVANCE') THEN amountYER WHEN kind IN ('COLLECTION','RETURN_CREDIT','MANUAL_CREDIT') THEN -amountYER ELSE 0 END), 0) FROM account_entries WHERE distributorId = :id")
    suspend fun ledgerBalance(id: String): Long

    @Query("SELECT * FROM account_entries WHERE distributorId = :id ORDER BY createdAt DESC")
    fun observeLedger(id: String): Flow<List<AccountEntry>>

    @Query("SELECT * FROM account_entries ORDER BY createdAt DESC")
    fun observeAllEntries(): Flow<List<AccountEntry>>
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE active = 1 ORDER BY name")
    fun observeAll(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getById(id: String): Product?

    @Insert
    suspend fun insert(item: Product)

    @Query("UPDATE products SET stockQty = stockQty + :delta WHERE id = :id AND stockQty + :delta >= 0")
    suspend fun changeStock(id: String, delta: Long): Int
}

@Dao
interface DistributionDao {
    @Insert suspend fun insert(item: Distribution)
    @Insert suspend fun insertItems(items: List<DistributionItem>)
    @Query("SELECT * FROM distributions ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<Distribution>>
}

@Dao
interface CollectionDao {
    @Insert suspend fun insert(item: CollectionEntry)
}

@Dao
interface ReturnDao {
    @Insert suspend fun insert(item: ReturnEntry)
}

@Dao
interface DamageDao {
    @Insert suspend fun insert(item: DamageEntry)
}

@Dao
interface AccountDao {
    @Insert suspend fun insert(item: AccountEntry)
    @Query("SELECT * FROM account_entries WHERE distributorId = :id AND createdAt >= :from AND createdAt < :to ORDER BY createdAt")
    suspend fun entriesBetween(id: String, from: Long, to: Long): List<AccountEntry>
}

@Dao
interface StockMovementDao {
    @Insert suspend fun insert(item: StockMovement)
}

@Dao
interface SettingsDao {
    @Query("SELECT value FROM settings WHERE key = :key")
    suspend fun get(key: String): String?

    @Query("INSERT OR REPLACE INTO settings (`key`, value) VALUES (:key, :value)")
    suspend fun put(key: String, value: String)
}


@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers WHERE active = 1 ORDER BY name")
    fun observeAll(): Flow<List<Supplier>>

    @Query("SELECT * FROM suppliers WHERE id = :id")
    suspend fun getById(id: String): Supplier?

    @Insert
    suspend fun insert(item: Supplier)

    @Query("SELECT COALESCE(SUM(CASE WHEN kind IN ('OPENING_BALANCE','PURCHASE_CREDIT','MANUAL_DEBIT') THEN amountYER WHEN kind IN ('PAYMENT','MANUAL_CREDIT') THEN -amountYER ELSE 0 END), 0) FROM supplier_entries WHERE supplierId = :id")
    suspend fun ledgerBalance(id: String): Long
}

@Dao
interface RawMaterialDao {
    @Query("SELECT * FROM raw_materials WHERE active = 1 ORDER BY name")
    fun observeAll(): Flow<List<RawMaterial>>

    @Query("SELECT * FROM raw_materials WHERE id = :id")
    suspend fun getById(id: String): RawMaterial?

    @Insert
    suspend fun insert(item: RawMaterial)

    @Query("UPDATE raw_materials SET stockQtyMilli = stockQtyMilli + :delta WHERE id = :id AND stockQtyMilli + :delta >= 0")
    suspend fun changeStock(id: String, delta: Long): Int

    @Query("UPDATE raw_materials SET averageCostPerUnitYER = :cost WHERE id = :id")
    suspend fun updateAverageCost(id: String, cost: Long): Int
}

@Dao
interface PurchaseDao {
    @Insert suspend fun insert(item: Purchase)
    @Insert suspend fun insertItems(items: List<PurchaseItem>)
    @Query("SELECT * FROM purchases ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<Purchase>>
}

@Dao
interface SupplierEntryDao {
    @Insert suspend fun insert(item: SupplierEntry)
    @Query("SELECT * FROM supplier_entries ORDER BY createdAt DESC")
    fun observeAllEntries(): Flow<List<SupplierEntry>>
}

@Dao
interface RecipeDao {
    @Query("SELECT * FROM recipes WHERE id = :id") suspend fun getRecipe(id: String): Recipe?
    @Insert suspend fun insert(item: Recipe)
    @Insert suspend fun insertItems(items: List<RecipeItem>)
    @Query("SELECT * FROM recipes WHERE active = 1 ORDER BY name")
    fun observeAll(): Flow<List<Recipe>>
    @Query("SELECT * FROM recipe_items WHERE recipeId = :recipeId")
    suspend fun itemsForRecipe(recipeId: String): List<RecipeItem>
}

@Dao
interface ProductionDao {
    @Insert suspend fun insert(item: ProductionBatch)
    @Query("SELECT * FROM production_batches ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<ProductionBatch>>
}
