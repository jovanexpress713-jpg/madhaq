package com.example.sweetsfactory.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(tableName = "distributors", indices = [Index("name")])
data class Distributor(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String = "",
    val debtLimitYER: Long = 0,
    val commissionType: String = "PER_PIECE", // PER_PIECE or PERCENT
    val commissionValue: Long = 0, // YER per piece, or basis points for percentage (e.g. 500 = 5%)
    val openingDebtYER: Long = 0,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "products", indices = [Index("name")])
data class Product(
    @PrimaryKey val id: String,
    val name: String,
    val category: String = "",
    val unit: String = "قطعة",
    val factoryPriceYER: Long,
    val distributorPriceYER: Long,
    val stockQty: Long = 0,
    val active: Boolean = true
)

@Entity(
    tableName = "distributions",
    foreignKeys = [ForeignKey(
        entity = Distributor::class,
        parentColumns = ["id"],
        childColumns = ["distributorId"],
        onDelete = ForeignKey.RESTRICT
    )],
    indices = [Index("distributorId"), Index("createdAt")]
)
data class Distribution(
    @PrimaryKey val id: String,
    val displayNumber: String,
    val distributorId: String,
    val createdAt: Long,
    val grossYER: Long,
    val cashPaidYER: Long,
    val creditYER: Long,
    val status: String = "POSTED",
    val note: String = ""
)

@Entity(
    tableName = "distribution_items",
    foreignKeys = [
        ForeignKey(entity = Distribution::class, parentColumns = ["id"], childColumns = ["distributionId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Product::class, parentColumns = ["id"], childColumns = ["productId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("distributionId"), Index("productId")]
)
data class DistributionItem(
    @PrimaryKey val id: String,
    val distributionId: String,
    val productId: String,
    val quantity: Long,
    val unitPriceYER: Long,
    val commissionTypeSnapshot: String,
    val commissionValueSnapshot: Long,
    val commissionYER: Long
)

@Entity(
    tableName = "collections",
    foreignKeys = [ForeignKey(entity = Distributor::class, parentColumns = ["id"], childColumns = ["distributorId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("distributorId"), Index("createdAt")]
)
data class CollectionEntry(
    @PrimaryKey val id: String,
    val distributorId: String,
    val createdAt: Long,
    val amountYER: Long,
    val method: String = "CASH",
    val note: String = ""
)

@Entity(
    tableName = "returns",
    foreignKeys = [ForeignKey(entity = Distributor::class, parentColumns = ["id"], childColumns = ["distributorId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("distributorId"), Index("createdAt")]
)
data class ReturnEntry(
    @PrimaryKey val id: String,
    val distributorId: String,
    val originalDistributionId: String?,
    val createdAt: Long,
    val valueYER: Long,
    val settlementType: String = "REDUCE_DEBT", // REDUCE_DEBT or CASH_REFUND
    val restockApproved: Boolean = false,
    val note: String = ""
)

@Entity(
    tableName = "damages",
    foreignKeys = [ForeignKey(entity = Distributor::class, parentColumns = ["id"], childColumns = ["distributorId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("distributorId"), Index("createdAt")]
)
data class DamageEntry(
    @PrimaryKey val id: String,
    val distributorId: String,
    val createdAt: Long,
    val valueYER: Long,
    val reason: String,
    val responsibility: String = "UNDECIDED",
    val note: String = ""
)

@Entity(tableName = "account_entries", indices = [Index("distributorId"), Index("createdAt"), Index("sourceId")])
data class AccountEntry(
    @PrimaryKey val id: String,
    val distributorId: String,
    val createdAt: Long,
    val kind: String, // DISTRIBUTION_CREDIT, COLLECTION, RETURN_CREDIT, MANUAL_DEBIT, MANUAL_CREDIT, ADVANCE
    val amountYER: Long,
    val sourceId: String?,
    val note: String = ""
)

@Entity(tableName = "stock_movements", indices = [Index("productId"), Index("createdAt")])
data class StockMovement(
    @PrimaryKey val id: String,
    val productId: String,
    val createdAt: Long,
    val quantityDelta: Long,
    val kind: String,
    val sourceId: String?,
    val note: String = ""
)


@Entity(tableName = "suppliers", indices = [Index("name")])
data class Supplier(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val openingBalanceYER: Long = 0,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "raw_materials", indices = [Index("name")])
data class RawMaterial(
    @PrimaryKey val id: String,
    val name: String,
    val unit: String = "كيلو",
    val stockQtyMilli: Long = 0, // quantity stored in thousandths to support fractional quantities
    val minimumQtyMilli: Long = 0,
    val averageCostPerUnitYER: Long = 0,
    val active: Boolean = true
)

@Entity(
    tableName = "purchases",
    foreignKeys = [ForeignKey(entity = Supplier::class, parentColumns = ["id"], childColumns = ["supplierId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("supplierId"), Index("createdAt")]
)
data class Purchase(
    @PrimaryKey val id: String,
    val displayNumber: String,
    val supplierId: String,
    val createdAt: Long,
    val totalYER: Long,
    val cashPaidYER: Long,
    val creditYER: Long,
    val note: String = ""
)

@Entity(
    tableName = "purchase_items",
    foreignKeys = [
        ForeignKey(entity = Purchase::class, parentColumns = ["id"], childColumns = ["purchaseId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = RawMaterial::class, parentColumns = ["id"], childColumns = ["rawMaterialId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("purchaseId"), Index("rawMaterialId")]
)
data class PurchaseItem(
    @PrimaryKey val id: String,
    val purchaseId: String,
    val rawMaterialId: String,
    val quantityMilli: Long,
    val unitCostYER: Long,
    val lineTotalYER: Long
)

@Entity(tableName = "recipes", indices = [Index("productId")])
data class Recipe(
    @PrimaryKey val id: String,
    val productId: String,
    val name: String,
    val outputQty: Long,
    val active: Boolean = true
)

@Entity(
    tableName = "recipe_items",
    foreignKeys = [
        ForeignKey(entity = Recipe::class, parentColumns = ["id"], childColumns = ["recipeId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = RawMaterial::class, parentColumns = ["id"], childColumns = ["rawMaterialId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("recipeId"), Index("rawMaterialId")]
)
data class RecipeItem(
    @PrimaryKey val id: String,
    val recipeId: String,
    val rawMaterialId: String,
    val quantityMilli: Long
)

@Entity(
    tableName = "production_batches",
    foreignKeys = [ForeignKey(entity = Product::class, parentColumns = ["id"], childColumns = ["productId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("productId"), Index("createdAt")]
)
data class ProductionBatch(
    @PrimaryKey val id: String,
    val displayNumber: String,
    val productId: String,
    val createdAt: Long,
    val plannedQty: Long,
    val producedQty: Long,
    val damagedQty: Long,
    val materialCostYER: Long,
    val note: String = ""
)

@Entity(
    tableName = "supplier_entries",
    foreignKeys = [ForeignKey(entity = Supplier::class, parentColumns = ["id"], childColumns = ["supplierId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("supplierId"), Index("createdAt")]
)
data class SupplierEntry(
    @PrimaryKey val id: String,
    val supplierId: String,
    val createdAt: Long,
    val kind: String, // PURCHASE_CREDIT, PAYMENT, MANUAL_DEBIT, MANUAL_CREDIT
    val amountYER: Long,
    val sourceId: String?,
    val note: String = ""
)
